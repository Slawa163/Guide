<?php
// Text
$_['text_title']                    = 'PayAnyWay (VISA, MasterCard and 30+ other ways)';
$_['text_ap_pay_with']              = 'Pay with';
$_['text_ap_and_other']             = 'or another payment method';
$_['text_ap_or']                    = 'or';
$_['text_paw_pay']                  = 'Pay';
$_['text_paw_list_methods']         = 'List of payment methods';
$_['text_paw_back_to_card']         = 'Back to payment by card';