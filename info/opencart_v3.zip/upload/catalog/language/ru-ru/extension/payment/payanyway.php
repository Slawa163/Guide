<?php
// Text
$_['text_title']                    = 'PayAnyWay (VISA, MasterCard, более 30-и способов оплаты)';
$_['text_ap_pay_with']              = 'Оплатить с';
$_['text_ap_and_other']             = 'или другой способ оплаты';
$_['text_ap_or']                    = 'или';
$_['text_paw_pay']                  = 'Оплатить';
$_['text_paw_list_methods']         = 'Список способов оплаты';
$_['text_paw_back_to_card']         = 'Вернуться к оплате картой';