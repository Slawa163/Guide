<?php

class ControllerExtensionPaymentPayanyway extends Controller
{

    private static $_domain = 'payanyway.ru';

    private function cleanProductName($str)
    {
        return trim(preg_replace('/[^0-9a-zA-Zа-яА-ЯёЁ\-\,\.\(\)\;\_\№\/\+\& ]/ui', '', htmlspecialchars_decode($str, ENT_QUOTES)));
    }

    public function index()
    {
        $this->load->language('extension/payment/payanyway');
        $this->load->model('checkout/order');

        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        if (isset($order_info['email']) && $order_info['email']) {
            $this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $this->config->get('config_order_status_id'));
        }

        $data['action'] = 'https://www.' . self::$_domain . '/assistant.htm';
        $data['sid'] = $this->config->get('payment_payanyway_account');
        $payanyway_secret = $this->config->get('payment_payanyway_secret');

        $data['currency_code'] = $order_info['currency_code'];
        if ($data['currency_code'] == 'RUR') {
            $data['currency_code'] = 'RUB';
        }

        $data['total'] = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
        $data['amount'] = number_format($order_info['total'], 2, '.', '');

        $data['timestamp'] = time();
        $data['delimiter'] = '~';

        $data['cart_order_id'] = $this->session->data['order_id'] . $data['delimiter'] . $data['timestamp'];
        $data['card_holder_name'] = $order_info['payment_firstname'] . ' ' . $order_info['payment_lastname'];
        $data['street_address'] = $order_info['payment_address_1'];
        $data['city'] = $order_info['payment_city'];

        if ($order_info['payment_iso_code_2'] == 'US' || $order_info['payment_iso_code_2'] == 'CA') {
            $data['state'] = $order_info['payment_zone'];
        } else {
            $data['state'] = 'XX';
        }

        $data['zip'] = $order_info['payment_postcode'];
        $data['country'] = $order_info['payment_country'];
        $data['email'] = $order_info['email'];
        $data['phone'] = $order_info['telephone'];

        if ($this->cart->hasShipping()) {
            $data['ship_street_address'] = $order_info['shipping_address_1'];
            $data['ship_city'] = $order_info['shipping_city'];
            $data['ship_state'] = $order_info['shipping_zone'];
            $data['ship_zip'] = $order_info['shipping_postcode'];
            $data['ship_country'] = $order_info['shipping_country'];
        } else {
            $data['ship_street_address'] = $order_info['payment_address_1'];
            $data['ship_city'] = $order_info['payment_city'];
            $data['ship_state'] = $order_info['payment_zone'];
            $data['ship_zip'] = $order_info['payment_postcode'];
            $data['ship_country'] = $order_info['payment_country'];
        }

        if ($this->config->get('payment_payanyway_test')) {
            $payanyway_test = '1';
        } else {
            $payanyway_test = '0';
        }

        $data['payanyway_test'] = $payanyway_test;

        // prepare signature
        // MNT_SIGNATURE = MD5(MNT_ID + MNT_TRANSACTION_ID + MNT_AMOUNT + MNT_CURRENCY_CODE + MNT_SUBSCRIBER_ID + ТЕСТОВЫЙ РЕЖИМ + КОД ПРОВЕРКИ ЦЕЛОСТНОСТИ ДАННЫХ)
        $data['MNT_SIGNATURE'] = md5($data['sid'] . $data['cart_order_id'] . $data['amount'] . $data['currency_code'] . $payanyway_test . $payanyway_secret);

        $data['lang'] = $this->session->data['language'];

        $data['return_url'] = $this->url->link('extension/payment/payanyway/callback', '', true);
//        $data['mnt_return_url'] = $this->url->link('common/home', '', true);
        $data['mnt_success_url'] = $this->url->link('extension/payment/payanyway/success');
        $data['mnt_fail_url'] = $this->url->link('checkout/checkout', '', 'SSL');
        $data['mnt_return_url'] = $this->url->link('checkout/checkout', '', 'SSL');

        $data['bank_cards'] = $this->config->get('payment_payanyway_bank_cards');

        $data['ap_text'] = $data['bank_cards'] ? $this->language->get('text_ap_and_other') : $this->language->get('text_ap_or');
        $data['ap_text_with'] = $this->language->get('text_ap_pay_with');
        $data['btn_confirm'] = $this->language->get('text_paw_pay');
        $data['btn_list_methods'] = $this->language->get('text_paw_list_methods');
        $data['btn_back_to_card'] = $this->language->get('text_paw_back_to_card');

        $data['ap_use'] = $this->config->get('payment_payanyway_ap_use');
        $data['ap_params'] = [
            'moneta_domain' => self::$_domain,
            'order_name' => $this->config->get('payment_payanyway_ap_payee'),
            'order_amount' => $data['amount'],
            'order_account_id' => $data['sid'],
            'transaction_id' => $data['cart_order_id'],
            'unit_id' => 'tcsapple',
            'order_salt' => uniqid(mt_rand(), true),
            'public_id' => $this->config->get('payment_payanyway_ap_public_id'),
        ];

        $data['ap_params']['order_signature'] = md5(
            $data['ap_params']['order_account_id'] .
            $data['ap_params']['order_salt'] .
            "RUB0" .
            $payanyway_secret
        );
        $data['ap_params']['sec_signature'] = md5(
            $data['ap_params']['order_account_id'] .
            $data['ap_params']['transaction_id'] .
            "DATAGRAM" .
            $payanyway_secret
        );
        $data['ap_params']['ass_signature'] = md5(
            $data['ap_params']['order_account_id'] .
            $data['ap_params']['transaction_id'] .
            $data['ap_params']['order_amount'] .
            "RUB0" .
            $payanyway_secret
        );

        return $this->load->view('extension/payment/payanyway', $data);
    }

    public function success()
    {
        $this->load->model('checkout/order');
        /* set pending status if not payed yet order will be confirmed otherway confirm will do nothing */
        $this->model_checkout_order->addOrderHistory($_REQUEST['MNT_TRANSACTION_ID'], $this->config->get('payment_payanyway_order_status_id'), 'Order confirmed');

        $this->response->redirect($this->url->link('checkout/success'));
    }

    const paw_kassa_VATNOVAT = 1105;  // НДС не облагается
    const paw_kassa_VAT0 = 1104;  // НДС 0%
    const paw_kassa_VAT10 = 1103;  // НДС 10%
    const paw_kassa_VAT20 = 7000;  // НДС 20%
    const paw_kassa_VATWR10 = 1107;  // НДС с рассч. ставкой 10%
    const paw_kassa_VATWR20 = 7001;  // НДС с рассч. ставкой 20%

    // Pay URL script
    // http://opencart-site/index.php?route=extension/payment/payanyway/callback
    public function callback()
    {
        $this->load->model('checkout/order');

        // MNT_SIGNATURE = MD5(MNT_ID + MNT_TRANSACTION_ID + MNT_OPERATION_ID + MNT_AMOUNT + MNT_CURRENCY_CODE + MNT_SUBSCRIBER_ID + MNT_TEST_MODE + КОД ПРОВЕРКИ ЦЕЛОСТНОСТИ ДАННЫХ)

        // get Pay URL data
        $MNT_ID = $this->getVar('MNT_ID');
        $MNT_TRANSACTION_ID = $this->getVar('MNT_TRANSACTION_ID');
        $MNT_OPERATION_ID = $this->getVar('MNT_OPERATION_ID');
        $MNT_AMOUNT = $this->getVar('MNT_AMOUNT');
        $MNT_CURRENCY_CODE = $this->getVar('MNT_CURRENCY_CODE');
        $MNT_TEST_MODE = $this->getVar('MNT_TEST_MODE');
        $MNT_SIGNATURE = $this->getVar('MNT_SIGNATURE');

        if ($MNT_TRANSACTION_ID && $MNT_SIGNATURE) {
            $mnt_dataintegrity_code = $this->config->get('payment_payanyway_secret');
            $check_signature = md5($MNT_ID . $MNT_TRANSACTION_ID . $MNT_OPERATION_ID . $MNT_AMOUNT . $MNT_CURRENCY_CODE . $MNT_TEST_MODE . $mnt_dataintegrity_code);

            if ($MNT_SIGNATURE == $check_signature) {
                $order_id = $MNT_TRANSACTION_ID;
                $order_info = $this->model_checkout_order->getOrder($order_id);
                if ($order_info) {
                    $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_payanyway_order_status_id'), 'Payment complete');

                    // begin of kassa.payanyway.ru code
                    $inventoryPositions = array();
                    $this->load->model('account/order');
                    /** @var ModelAccountOrder $modelAccountOrder */
                    $modelAccountOrder = $this->model_account_order;
                    $products = $modelAccountOrder->getOrderProducts($order_id);
                    $orderTotals = $modelAccountOrder->getOrderTotals($order_id);
                    foreach ($products as $product) {
                        $inventoryPositions[] = array(
                            'name' => $this->cleanProductName($product['name']),
                            'price' => number_format($product['price'], 2, '.', ''),
                            'quantity' => $product['quantity'],
                            'vatTag' => self::paw_kassa_VATNOVAT,
                        );
                    }
                    $kassa_delivery = null;
                    foreach ($orderTotals as $orderTotal)
                        if ($orderTotal['code'] == 'shipping') {
                            $kassa_delivery = number_format($orderTotal['value'], 2, '.', '');
                            break;
                        }
                    $kassa_inventory = json_encode($inventoryPositions);
                    self::monetaPayURLResponse($_REQUEST['MNT_ID'], $_REQUEST['MNT_TRANSACTION_ID'],
                        $mnt_dataintegrity_code, true, false, true, true, $kassa_inventory, $order_info['email'],
                        $kassa_delivery);

                    exit;
                }
            }
        }

        echo 'FAIL';
    }

    private static function monetaPayURLResponse($mnt_id, $mnt_transaction_id, $mnt_data_integrity_code, $success = false,
                                                 $repeatRequest = false, $echo = true, $die = true, $kassa_inventory = null, $kassa_customer = null, $kassa_delivery = null)
    {
        if ($success === true)
            $resultCode = '200';
        elseif ($repeatRequest === true)
            $resultCode = '402';
        else
            $resultCode = '500';
        $mnt_signature = md5($resultCode . $mnt_id . $mnt_transaction_id . $mnt_data_integrity_code);
        $response = '<?xml version="1.0" encoding="UTF-8" ?>' . "\n";
        $response .= "<MNT_RESPONSE>\n";
        $response .= "<MNT_ID>{$mnt_id}</MNT_ID>\n";
        $response .= "<MNT_TRANSACTION_ID>{$mnt_transaction_id}</MNT_TRANSACTION_ID>\n";
        $response .= "<MNT_RESULT_CODE>{$resultCode}</MNT_RESULT_CODE>\n";
        $response .= "<MNT_SIGNATURE>{$mnt_signature}</MNT_SIGNATURE>\n";
        $response .= "<MNT_ATTRIBUTES>\n";
        $response .= "<ATTRIBUTE>\n";
        $response .= "<KEY>cms</KEY>\n";
        $response .= "<VALUE>opencart</VALUE>\n";
        $response .= "</ATTRIBUTE>\n";
        $response .= "<ATTRIBUTE>\n";
        $response .= "<KEY>cms_m</KEY>\n";
        $response .= "<VALUE></VALUE>\n";
        $response .= "</ATTRIBUTE>\n";

        if (!empty($kassa_inventory) || !empty($kassa_customer) || !empty($kassa_delivery)) {
            foreach (array('INVENTORY' => $kassa_inventory, 'CUSTOMER' => $kassa_customer, 'DELIVERY' => $kassa_delivery) as $k => $v)
                if (!empty($v))
                    $response .= "<ATTRIBUTE><KEY>{$k}</KEY><VALUE>{$v}</VALUE></ATTRIBUTE>\n";
        }

        $response .= "</MNT_ATTRIBUTES>\n";
        $response .= "</MNT_RESPONSE>\n";

        if ($echo === true) {
            header("Content-type: application/xml");
            echo $response;
        } else
            return $response;
        if ($die === true)
            die;
        return '';
    }

    private function getVar($name)
    {
        $value = false;
        if (isset($_POST[$name])) {
            $value = $_POST[$name];
        } else if (isset($_GET[$name])) {
            $value = $_GET[$name];
        }

        return $value;
    }
}