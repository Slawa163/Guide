<?php

$_['payment_payanyway_bank_cards'] = 1;

?>