#!/usr/bin/env python3

from monetasdkmethods import *

# result = sdkGetProfileInfo(40488)
# print(result)

# result = templateChoosePaymentSystemForm()
# print(result)

# result = templatePaymentFrom('plastic', null, 123, 2.89, 'RUB')
# print(result)

# result = showAccountBalance()
# print(result)

# result = showOperationInfo(387980)
# print(result)

# result = createInvoice(payer='303', payee='12345678', amount='10.00', orderId='pysdkTest01');
# print(result);
